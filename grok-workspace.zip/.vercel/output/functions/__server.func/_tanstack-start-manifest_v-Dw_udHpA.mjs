//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dw_udHpA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BeFnFRVX.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BeFnFRVX.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DDObbHNZ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
