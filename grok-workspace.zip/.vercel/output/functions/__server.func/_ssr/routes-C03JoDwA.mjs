import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Search, c as Megaphone, d as Compass, f as ArrowUpRight, i as Target, l as Layers, n as Users, o as PenLine, p as ArrowRight, s as Menu, t as X, u as Eye } from "../_libs/lucide-react.mjs";
import { a as REASONS, c as SOCIALS, i as PROBLEMS, l as STEPS, n as AUDIENCES, o as SERVICES, r as NAV, s as SITE } from "./router-C6SfPRv9.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C03JoDwA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function scrollToId(id) {
	if (id === "home" || id === "top") {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
		return;
	}
	const el = document.getElementById(id);
	if (el) el.scrollIntoView({
		behavior: "smooth",
		block: "start"
	});
}
function Reveal({ children, className, delay = 0 }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const node = ref.current;
		if (!node) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			node.classList.add("is-in");
			return;
		}
		const io = new IntersectionObserver(([entry]) => {
			if (entry?.isIntersecting) {
				node.classList.add("is-in");
				io.disconnect();
			}
		}, {
			threshold: .14,
			rootMargin: "0px 0px -8% 0px"
		});
		io.observe(node);
		return () => io.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: cn("reveal", className),
		style: delay ? { transitionDelay: `${delay}ms` } : void 0,
		children
	});
}
function base(props) {
	return {
		width: 20,
		height: 20,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 1.7,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		...props
	};
}
function InstagramIcon(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		...base(props),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3",
				y: "3",
				width: "18",
				height: "18",
				rx: "5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "17.5",
				cy: "6.5",
				r: "0.6",
				fill: "currentColor",
				stroke: "none"
			})
		]
	});
}
function FacebookIcon(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		...base(props),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M14 8h3V4h-3c-2.8 0-5 2.2-5 5v3H6v4h3v8h4v-8h3.2L17 12h-4V9c0-.6.4-1 1-1Z" })
	});
}
function YoutubeIcon(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		...base(props),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M22.5 7.2a3 3 0 0 0-2.1-2.1C18.6 4.6 12 4.6 12 4.6s-6.6 0-8.4.5A3 3 0 0 0 1.5 7.2 31 31 0 0 0 1 12a31 31 0 0 0 .5 4.8 3 3 0 0 0 2.1 2.1c1.8.5 8.4.5 8.4.5s6.6 0 8.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 23 12a31 31 0 0 0-.5-4.8Z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "m10 15.2 5.2-3.2L10 8.8v6.4Z",
			fill: "currentColor",
			stroke: "none"
		})]
	});
}
function SnapchatIcon(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		...base(props),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 4c2.4 0 4.2 1.7 4.2 4.4 0 1.1.1 1.9.6 2.4.3.3.8.4 1.2.3.2 0 .5-.1.7 0 .4.2.4.7 0 1-.7.6-1.3 1-1.3 1.6 0 1.3 2.2 1.9 2.8 2.2.4.2.5.7.2 1-.4.5-1.3.8-2.4.6-.3 0-.6.2-.7.5-.3.8-1.3 2.2-5.3 2.2s-5-1.4-5.3-2.2c-.1-.3-.4-.5-.7-.5-1.1.2-2 0-2.4-.6-.3-.3-.2-.8.2-1 .6-.3 2.8-.9 2.8-2.2 0-.6-.6-1-1.3-1.6-.4-.3-.4-.8 0-1 .2-.1.5 0 .7 0 .4.1.9 0 1.2-.3.5-.5.6-1.3.6-2.4C7.8 5.7 9.6 4 12 4Z" })
	});
}
function MailIcon(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		...base(props),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "3",
			y: "5",
			width: "18",
			height: "14",
			rx: "2"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m4 7 8 6 8-6" })]
	});
}
var SOCIAL_ICONS = {
	instagram: InstagramIcon,
	facebook: FacebookIcon,
	snapchat: SnapchatIcon,
	youtube: YoutubeIcon,
	email: MailIcon
};
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-sans font-semibold uppercase tracking-widest transition-[background-color,color,box-shadow,transform] duration-150 ease-[var(--ease-out)] active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-50", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg shadow-[0_10px_24px_-12px_color-mix(in_oklab,var(--color-accent)_70%,transparent)] hover:bg-accent-hover",
			navy: "bg-navy text-paper hover:bg-navy-soft",
			outline: "bg-transparent text-navy shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] hover:bg-cream",
			invert: "bg-paper text-navy hover:bg-cream",
			ghost: "bg-transparent text-paper shadow-[inset_0_0_0_1px_color-mix(in_oklab,var(--color-paper)_28%,transparent)] hover:bg-paper-ghost"
		},
		size: {
			md: "h-12 rounded-full px-6 text-xs",
			lg: "h-14 rounded-full px-8 text-xs"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var VALUE = [
	{
		title: "Build",
		body: "Create a clear and professional identity for your brand.",
		icon: Layers
	},
	{
		title: "Connect",
		body: "Help your brand communicate with the people who matter.",
		icon: Users
	},
	{
		title: "Grow",
		body: "Build a stronger online presence that supports long-term growth.",
		icon: Target
	}
];
var SERVICE_ICONS = [
	Compass,
	Megaphone,
	PenLine,
	Layers,
	Eye,
	Search
];
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "home",
		className: "bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ValueStrip, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionVision, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Problem, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhyPheno, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Process, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhoWeHelp, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Philosophy, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallToAction, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {})
		]
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -left-24 top-10 size-[28rem] rounded-full bg-lavender-soft/70 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl items-center gap-12 px-5 pb-10 pt-10 md:px-8 md:pb-16 md:pt-16 lg:grid-cols-12 lg:gap-10 lg:pt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-accent",
						children: ["Digital branding studio · ", SITE.handle]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 font-display text-[2.6rem] leading-[1.08] text-navy sm:text-5xl lg:text-[3.55rem]",
						children: "Your Brand Deserves To Be Seen, Understood & Remembered."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg",
						children: "We help businesses build a stronger online presence, communicate their value clearly and connect with the right audience."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-sm leading-relaxed text-muted-soft",
						children: "Pheno Brand helps businesses build a clear, professional and engaging online presence through smart digital branding, content strategy and online visibility solutions."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "lg",
							onClick: () => scrollToId("contact"),
							children: ["Get started", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							variant: "outline",
							onClick: () => scrollToId("services"),
							children: "See what we offer"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative lg:col-span-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto max-w-md lg:max-w-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute -left-6 top-10 hidden rounded-full bg-navy px-4 py-2 text-[0.65rem] font-semibold uppercase tracking-widest text-lavender sm:block",
							children: "Build · Brand · Grow"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-[2rem] bg-cream shadow-[var(--shadow-border)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/brand/hero.jpg",
								alt: "A branding professional reviewing a brand presence on her phone in a sunlit studio",
								width: 900,
								height: 1200,
								className: "aspect-[3/4] w-full object-cover object-[50%_18%] sm:aspect-[4/5]"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute -bottom-5 left-4 right-4 rounded-2xl bg-paper/95 p-4 shadow-[var(--shadow-border)] backdrop-blur-sm sm:left-auto sm:right-[-0.75rem] sm:w-64",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[0.65rem] font-semibold uppercase tracking-widest text-accent",
								children: "Digital branding"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-xl leading-snug text-navy",
								children: "Look better. Speak clearer. Reach the right people."
							})]
						})
					]
				})
			})]
		})]
	});
}
function ValueStrip() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative z-10 px-5 pb-8 pt-16 md:px-8 md:pt-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-6xl gap-4 md:grid-cols-3",
			children: VALUE.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: i * 80,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-[1.75rem] bg-navy p-7 text-paper shadow-[var(--shadow-navy)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
							className: "size-5 text-lavender",
							strokeWidth: 1.7
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-6 font-sans text-xs font-bold uppercase tracking-widest",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-paper/75",
							children: item.body
						})
					]
				})
			}, item.title))
		})
	});
}
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "about",
		className: "scroll-mt-24 px-5 py-20 md:px-8 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-12 lg:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "lg:col-span-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-accent",
						children: "About Pheno Brand"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-4xl leading-tight text-navy md:text-5xl",
						children: "More Than Just A Pretty Page."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-7 space-y-4 text-[0.975rem] leading-relaxed text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "At Pheno Brand, we believe a strong online presence starts with clarity." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Many businesses are online but struggle to communicate what they do, who they serve or why people should choose them." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "That is where we come in." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Pheno Brand helps businesses transform scattered online presence into clear, professional and engaging digital brands." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We combine creativity, strategy and audience-focused thinking to help businesses present themselves better online." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-navy",
								children: "Our goal is simple: make your brand easier to notice, easier to understand and harder to forget."
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				className: "lg:col-span-6",
				delay: 100,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-[2rem] shadow-[var(--shadow-border)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/brand/studio-desk.jpg",
							alt: "A digital branding studio desk with a laptop, phone, colour swatches and creative notes",
							width: 1200,
							height: 900,
							className: "aspect-[4/3] w-full object-cover",
							loading: "lazy"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute -bottom-6 -left-2 hidden max-w-[16rem] rounded-2xl bg-navy p-5 text-paper shadow-[var(--shadow-navy)] sm:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl leading-snug",
							children: "Strategy, social and a digital identity that holds together."
						})
					})]
				})
			})]
		})
	});
}
function MissionVision() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-5 pb-8 md:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-5 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "h-full rounded-[2rem] bg-cream p-8 md:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-accent",
						children: "Our mission"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-3xl text-navy md:text-4xl",
						children: "Our Mission"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 leading-relaxed text-muted",
						children: "To help businesses and entrepreneurs build meaningful digital brands by making online branding clearer, more strategic and accessible."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 leading-relaxed text-muted",
						children: "We want to help brands move beyond simply “being online” and start building an online presence that actually communicates their value."
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 80,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "h-full rounded-[2rem] bg-navy p-8 text-paper md:p-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-widest text-lavender",
							children: "Our vision"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-3xl md:text-4xl",
							children: "Our Vision"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 leading-relaxed text-paper/75",
							children: "To become a trusted digital branding partner for businesses that want to be seen, understood and remembered in an increasingly digital world."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 leading-relaxed text-paper/75",
							children: "We envision a world where every business — regardless of size — has the tools and confidence to present itself professionally online."
						})
					]
				})
			})]
		})
	});
}
function Services() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "services",
		className: "scroll-mt-24 px-5 py-20 md:px-8 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-accent",
						children: "What we offer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 max-w-xl font-display text-4xl text-navy md:text-5xl",
						children: "What We Do"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-lg text-muted",
						children: "We turn ideas into stronger digital identities."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
					children: SERVICES.map((service, i) => {
						const Icon = SERVICE_ICONS[i] ?? Compass;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i * 50,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "group flex h-full flex-col rounded-[1.75rem] bg-paper p-7 shadow-[var(--shadow-border)] transition-[transform,box-shadow] duration-200 ease-[var(--ease-out)] hover:-translate-y-1 hover:shadow-[var(--shadow-border-hover)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-semibold tracking-widest text-muted-soft",
											children: service.number
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-5 text-accent transition-transform duration-200 group-hover:translate-x-0.5",
											strokeWidth: 1.7
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-6 font-sans text-sm font-bold uppercase tracking-widest text-navy",
										children: service.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 flex-1 text-sm leading-relaxed text-muted",
										children: service.body
									})
								]
							})
						}, service.number);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "mt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						variant: "navy",
						onClick: () => scrollToId("contact"),
						children: ["Let's improve your brand", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
					})
				})
			]
		})
	});
}
function Problem() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-5 pb-8 md:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-6xl overflow-hidden rounded-[2rem] bg-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/brand/strategy-hands.jpg",
						alt: "Hands arranging printed brand identity cards and colour chips on a studio table",
						width: 1200,
						height: 900,
						className: "h-full min-h-72 w-full object-cover",
						loading: "lazy"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 p-8 md:p-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl leading-tight text-navy md:text-4xl",
							children: "Is Your Brand Being Seen — But Not Remembered?"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 space-y-6",
							children: PROBLEMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-xl italic text-navy",
								children: [
									"“",
									item.quote,
									"”"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: item.answer
							})] }) }, item.quote))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-10 font-sans text-sm font-semibold uppercase tracking-widest text-navy",
							children: "Your business may be good. Your online presence should show it."
						})
					]
				})]
			})
		})
	});
}
function WhyPheno() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "why",
		className: "scroll-mt-24 px-5 py-20 md:px-8 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-widest text-accent",
					children: "Why Pheno Brand"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 font-display text-4xl text-navy md:text-5xl",
					children: "Why Choose Pheno?"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-4 md:grid-cols-2",
					children: REASONS.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * 60,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-[1.75rem] border border-line bg-paper p-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-sans text-sm font-bold uppercase tracking-widest text-navy",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-muted",
								children: item.body
							})]
						})
					}, item.title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "mt-12 rounded-[2rem] bg-lavender-soft px-8 py-12 md:px-14",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-3xl font-display text-3xl leading-snug text-navy md:text-4xl",
						children: "“We don't just help you look good online. We help you make sense online.”"
					})
				})
			]
		})
	});
}
function Process() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-5 pb-8 md:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl rounded-[2rem] bg-navy px-6 py-14 text-paper md:px-12 md:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-widest text-lavender",
				children: "Our process"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-4 font-display text-4xl md:text-5xl",
				children: "Four steps. One clearer brand."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-14 grid gap-10 md:grid-cols-4 md:gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute left-[12%] right-[12%] top-5 hidden h-px bg-paper/15 md:block" }), STEPS.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 80,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex size-10 items-center justify-center rounded-full bg-lavender text-xs font-bold text-navy",
								children: step.number
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-6 font-sans text-sm font-bold uppercase tracking-widest",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-paper/70",
								children: step.body
							})
						]
					})
				}, step.number))]
			})]
		})
	});
}
function WhoWeHelp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-5 py-20 md:px-8 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-accent",
						children: "Who we help"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-4xl text-navy md:text-5xl",
						children: "Built For Brands With Something To Say."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-md leading-relaxed text-muted",
						children: "Whether you're starting from zero or trying to improve an existing online presence, Pheno Brand helps you take the next step."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid grid-cols-2 gap-3",
					children: AUDIENCES.map((name, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * 40,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-2xl bg-cream px-4 py-5 text-sm font-semibold text-navy",
							children: name
						})
					}, name))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				className: "lg:col-span-6",
				delay: 80,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-[2rem] shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/brand/collaboration.jpg",
						alt: "Two people reviewing a brand board together in a bright studio",
						width: 1600,
						height: 900,
						className: "aspect-[16/11] w-full object-cover",
						loading: "lazy"
					})
				})
			})]
		})
	});
}
function Philosophy() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "grain relative overflow-hidden bg-navy text-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-6xl px-5 py-24 md:px-8 md:py-32",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-widest text-lavender",
					children: "Brand philosophy"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-6 font-display text-5xl leading-[0.95] sm:text-6xl md:text-8xl",
					children: [
						"Be seen.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"Be clear.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"Be remembered."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 max-w-xl text-lg leading-relaxed text-paper/70",
					children: "Attention gets people to notice your brand. Clarity helps them understand it. Consistency helps them remember it."
				})
			] })
		})
	});
}
function CallToAction() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-5 py-16 md:px-8 md:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl overflow-hidden rounded-[2rem] bg-accent px-8 py-14 text-accent-fg md:px-16 md:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "max-w-3xl font-display text-4xl leading-tight md:text-5xl",
					children: "Ready To Give Your Brand A Stronger Digital Presence?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-xl text-base leading-relaxed text-accent-fg/85",
					children: "Let's turn your online presence into something your audience can notice, understand and remember."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						variant: "invert",
						onClick: () => scrollToId("contact"),
						children: ["Start with Pheno", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "ghost",
						onClick: () => scrollToId("contact"),
						children: "Contact us"
					})]
				})
			]
		}) })
	});
}
function Contact() {
	const [sent, setSent] = (0, import_react.useState)(false);
	function onSubmit(e) {
		e.preventDefault();
		const data = new FormData(e.currentTarget);
		const name = String(data.get("name") ?? "").trim();
		const email = String(data.get("email") ?? "").trim();
		const brand = String(data.get("brand") ?? "").trim();
		const message = String(data.get("message") ?? "").trim();
		const subject = encodeURIComponent(`Brand inquiry from ${name || "a new client"}`);
		const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nBrand: ${brand}\n\n${message}`);
		window.location.href = `mailto:${SITE.email}?subject=${subject}&body=${body}`;
		setSent(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contact",
		className: "scroll-mt-24 px-5 pb-20 md:px-8 md:pb-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-12 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-accent",
						children: "Contact"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-4xl text-navy md:text-5xl",
						children: "Let's Talk About Your Brand."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 leading-relaxed text-muted",
						children: "Have a business idea, an existing brand or simply want to improve your online presence? We'd love to hear from you."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 space-y-3",
						children: SOCIALS.map((s) => {
							const Icon = SOCIAL_ICONS[s.id];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: s.href,
								target: s.id === "email" ? void 0 : "_blank",
								rel: s.id === "email" ? void 0 : "noreferrer",
								className: "group flex min-h-12 items-center gap-4 rounded-2xl bg-cream px-4 py-3 transition-colors duration-150 hover:bg-lavender-soft",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-10 items-center justify-center rounded-full bg-navy text-paper",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-semibold uppercase tracking-widest text-muted",
									children: s.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-navy",
									children: s.handle
								})] })]
							}) }, s.id);
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				className: "lg:col-span-7",
				delay: 80,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "rounded-[2rem] bg-cream p-6 md:p-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl text-navy",
							children: "Send a note"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Tell us a little about your brand. This opens your email app so the message goes directly to Pheno Brand."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid gap-5 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-semibold uppercase tracking-widest text-muted",
								children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "name",
									required: true,
									autoComplete: "name",
									className: "mt-2 h-12 w-full rounded-xl bg-paper px-4 font-sans text-sm font-medium text-navy outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-semibold uppercase tracking-widest text-muted",
								children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "email",
									type: "email",
									required: true,
									autoComplete: "email",
									className: "mt-2 h-12 w-full rounded-xl bg-paper px-4 font-sans text-sm font-medium text-navy outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-5 block text-xs font-semibold uppercase tracking-widest text-muted",
							children: ["Brand or business", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								name: "brand",
								className: "mt-2 h-12 w-full rounded-xl bg-paper px-4 font-sans text-sm font-medium text-navy outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-5 block text-xs font-semibold uppercase tracking-widest text-muted",
							children: ["Message", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								name: "message",
								required: true,
								rows: 5,
								className: "mt-2 w-full resize-y rounded-xl bg-paper px-4 py-3 font-sans text-sm font-medium text-navy outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							size: "lg",
							className: "mt-6",
							children: [sent ? "Opening your email" : "Send message", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						})
					]
				})
			})]
		})
	});
}
function Logo({ className, inverted = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("flex items-center gap-2.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/brand/logo.jpg",
			alt: "",
			width: 40,
			height: 40,
			className: "size-10 rounded-full object-cover outline-none"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("font-sans text-[0.7rem] font-bold tracking-[0.22em]", inverted ? "text-paper" : "text-navy"),
				children: "PHENO BRAND"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("mt-1 text-[0.58rem] tracking-[0.18em]", inverted ? "text-lavender" : "text-muted"),
				children: "BUILD · BRAND · GROW"
			})]
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "bg-navy text-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-12 md:px-8 md:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { inverted: true }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-sm font-display text-2xl leading-snug text-paper",
							children: "Build. Brand. Grow."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-sm text-sm leading-relaxed text-lavender",
							children: "Helping businesses build stronger, clearer and more memorable digital brands."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.18em] text-lavender",
						children: "Navigate"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-4 flex flex-col gap-2",
						"aria-label": "Footer",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => scrollToId(item.id),
							className: "min-h-10 w-fit text-left text-sm text-paper/80 hover:text-paper",
							children: item.label
						}, item.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.18em] text-lavender",
						children: "Connect"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-2",
						children: SOCIALS.map((s) => {
							const Icon = SOCIAL_ICONS[s.id];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: s.href,
								target: s.id === "email" ? void 0 : "_blank",
								rel: s.id === "email" ? void 0 : "noreferrer",
								className: "inline-flex min-h-10 items-center gap-3 text-sm text-paper/80 hover:text-paper",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									s.label,
									" · ",
									s.handle
								] })]
							}) }, s.id);
						})
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-paper/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-3 px-5 py-6 text-xs text-paper/55 md:flex-row md:items-center md:justify-between md:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "© 2026 Pheno Brand. All Rights Reserved." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Digital Branding • Content Strategy • Online Presence" })]
			})
		})]
	});
}
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 8);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	function go(id) {
		setOpen(false);
		requestAnimationFrame(() => scrollToId(id));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("sticky top-0 z-50 border-b transition-[background-color,box-shadow,border-color] duration-200", scrolled ? "border-line bg-paper/90 shadow-[0_8px_30px_-20px_color-mix(in_oklab,var(--color-navy)_40%,transparent)] backdrop-blur-md" : "border-transparent bg-paper/80 backdrop-blur-md"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-[4.25rem] w-full max-w-6xl items-center justify-between gap-4 px-5 md:h-[4.75rem] md:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => go("home"),
					className: "rounded-full",
					"aria-label": "Pheno Brand home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-7 lg:flex",
					"aria-label": "Primary",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go(item.id),
						className: "font-sans text-sm font-medium text-muted transition-colors duration-150 hover:text-navy",
						children: item.label
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "navy",
						className: "hidden sm:inline-flex",
						onClick: () => go("contact"),
						children: "Let's build your brand"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-11 items-center justify-center rounded-full text-navy lg:hidden",
						"aria-label": open ? "Close menu" : "Open menu",
						"aria-expanded": open,
						onClick: () => setOpen((v) => !v),
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-6" })
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("lg:hidden", open ? "pointer-events-auto" : "pointer-events-none"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("fixed inset-0 top-[4.25rem] bg-navy/30 transition-opacity duration-200 md:top-[4.75rem]", open ? "opacity-100" : "opacity-0"),
				onClick: () => setOpen(false)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("absolute inset-x-0 top-full origin-top border-b border-line bg-paper px-5 py-6 shadow-[var(--shadow-border)] transition-[opacity,transform] duration-200 ease-[var(--ease-smooth-out)] md:px-8", open ? "scale-100 opacity-100" : "scale-[0.98] opacity-0"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-col gap-1",
					"aria-label": "Mobile",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go(item.id),
						className: "flex min-h-12 items-center justify-between rounded-xl px-3 text-left font-display text-2xl text-navy hover:bg-cream",
						children: item.label
					}, item.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "navy",
					className: "mt-5 w-full sm:hidden",
					onClick: () => go("contact"),
					children: "Let's build your brand"
				})]
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Home as component };
