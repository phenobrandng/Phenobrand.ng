import { Logo } from "@/components/logo";
import { SOCIAL_ICONS } from "@/components/social-icons";
import { NAV, SOCIALS } from "@/lib/site";
import { scrollToId } from "@/lib/utils";

export function SiteFooter() {
  return (
    <footer className="bg-navy text-paper">
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-12 md:px-8 md:py-20">
        <div className="md:col-span-5">
          <Logo inverted />
          <p className="mt-5 max-w-sm font-display text-2xl leading-snug text-paper">
            Build. Brand. Grow.
          </p>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-lavender">
            Helping businesses build stronger, clearer and more memorable
            digital brands.
          </p>
        </div>

        <div className="md:col-span-3">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-lavender">
            Navigate
          </p>
          <nav className="mt-4 flex flex-col gap-2" aria-label="Footer">
            {NAV.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => scrollToId(item.id)}
                className="min-h-10 w-fit text-left text-sm text-paper/80 hover:text-paper"
              >
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="md:col-span-4">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-lavender">
            Connect
          </p>
          <ul className="mt-4 flex flex-col gap-2">
            {SOCIALS.map((s) => {
              const Icon = SOCIAL_ICONS[s.id];
              return (
                <li key={s.id}>
                  <a
                    href={s.href}
                    target={s.id === "email" ? undefined : "_blank"}
                    rel={s.id === "email" ? undefined : "noreferrer"}
                    className="inline-flex min-h-10 items-center gap-3 text-sm text-paper/80 hover:text-paper"
                  >
                    <Icon className="size-4" />
                    <span>
                      {s.label} · {s.handle}
                    </span>
                  </a>
                </li>
              );
            })}
          </ul>
        </div>
      </div>

      <div className="border-t border-paper/10">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-5 py-6 text-xs text-paper/55 md:flex-row md:items-center md:justify-between md:px-8">
          <p>© 2026 Pheno Brand. All Rights Reserved.</p>
          <p>Digital Branding • Content Strategy • Online Presence</p>
        </div>
      </div>
    </footer>
  );
}
