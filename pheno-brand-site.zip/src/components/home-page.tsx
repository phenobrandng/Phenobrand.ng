import { useState, type FormEvent } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  Compass,
  Eye,
  Layers,
  Megaphone,
  PenLine,
  Search,
  Target,
  Users,
} from "lucide-react";
import { Reveal } from "@/components/reveal";
import { SOCIAL_ICONS } from "@/components/social-icons";
import { Button } from "@/components/ui/button";
import {
  AUDIENCES,
  PROBLEMS,
  REASONS,
  SERVICES,
  SITE,
  SOCIALS,
  STEPS,
} from "@/lib/site";
import { scrollToId } from "@/lib/utils";

const VALUE = [
  {
    title: "Build",
    body: "Create a clear and professional identity for your brand.",
    icon: Layers,
  },
  {
    title: "Connect",
    body: "Help your brand communicate with the people who matter.",
    icon: Users,
  },
  {
    title: "Grow",
    body: "Build a stronger online presence that supports long-term growth.",
    icon: Target,
  },
];

const SERVICE_ICONS = [Compass, Megaphone, PenLine, Layers, Eye, Search];

export function HomePage() {
  return (
    <main id="home" className="bg-paper text-ink">
      <Hero />
      <ValueStrip />
      <About />
      <MissionVision />
      <Services />
      <Problem />
      <WhyPheno />
      <Process />
      <WhoWeHelp />
      <Philosophy />
      <CallToAction />
      <Contact />
    </main>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="pointer-events-none absolute -left-24 top-10 size-[28rem] rounded-full bg-lavender-soft/70 blur-3xl" />
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 pb-10 pt-10 md:px-8 md:pb-16 md:pt-16 lg:grid-cols-12 lg:gap-10 lg:pt-8">
        <div className="lg:col-span-6">
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">
            Digital branding studio · {SITE.handle}
          </p>
          <h1 className="mt-5 font-display text-[2.6rem] leading-[1.08] text-navy sm:text-5xl lg:text-[3.55rem]">
            Your Brand Deserves To Be Seen, Understood & Remembered.
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
            We help businesses build a stronger online presence, communicate
            their value clearly and connect with the right audience.
          </p>
          <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-soft">
            Pheno Brand helps businesses build a clear, professional and
            engaging online presence through smart digital branding, content
            strategy and online visibility solutions.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button size="lg" onClick={() => scrollToId("contact")}>
              Get started
              <ArrowRight className="size-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => scrollToId("services")}
            >
              See what we offer
            </Button>
          </div>
        </div>

        <div className="relative lg:col-span-6">
          <div className="relative mx-auto max-w-md lg:max-w-none">
            <div className="absolute left-4 top-10 hidden rounded-full bg-navy px-4 py-2 text-xs font-semibold uppercase tracking-widest text-lavender sm:block">
              Build · Brand · Grow
            </div>
            <div className="overflow-hidden rounded-3xl bg-cream shadow-[var(--shadow-border)]">
              <img
                src={`${import.meta.env.BASE_URL}brand/hero.jpg`}
                alt="A branding professional reviewing a brand presence on her phone in a sunlit studio"
                width={900}
                height={1200}
                className="aspect-[3/4] w-full object-cover object-top sm:aspect-[4/5]"
              />
            </div>
            <div className="absolute bottom-4 left-4 right-4 rounded-2xl bg-paper/95 p-4 shadow-[var(--shadow-border)] backdrop-blur-sm sm:left-auto sm:right-4 sm:w-64">
              <p className="text-[0.65rem] font-semibold uppercase tracking-widest text-accent">
                Digital branding
              </p>
              <p className="mt-1 font-display text-xl leading-snug text-navy">
                Look better. Speak clearer. Reach the right people.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ValueStrip() {
  return (
    <section className="relative z-10 px-5 pb-8 pt-16 md:px-8 md:pt-20">
      <div className="mx-auto grid max-w-6xl gap-4 md:grid-cols-3">
        {VALUE.map((item, i) => (
          <Reveal key={item.title} delay={i * 80}>
            <article className="rounded-3xl bg-navy p-7 text-paper shadow-[var(--shadow-navy)]">
              <item.icon className="size-5 text-lavender" strokeWidth={1.7} />
              <p className="mt-6 font-sans text-xs font-bold uppercase tracking-widest">
                {item.title}
              </p>
              <p className="mt-3 text-sm leading-relaxed text-paper/75">
                {item.body}
              </p>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="scroll-mt-24 px-5 py-20 md:px-8 md:py-28">
      <div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-12 lg:gap-16">
        <Reveal className="lg:col-span-6">
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">
            About Pheno Brand
          </p>
          <h2 className="mt-4 font-display text-4xl leading-tight text-navy md:text-5xl">
            More Than Just A Pretty Page.
          </h2>
          <div className="mt-7 space-y-4 text-[0.975rem] leading-relaxed text-muted">
            <p>
              At Pheno Brand, we believe a strong online presence starts with
              clarity.
            </p>
            <p>
              Many businesses are online but struggle to communicate what they
              do, who they serve or why people should choose them.
            </p>
            <p>That is where we come in.</p>
            <p>
              Pheno Brand helps businesses transform scattered online presence
              into clear, professional and engaging digital brands.
            </p>
            <p>
              We combine creativity, strategy and audience-focused thinking to
              help businesses present themselves better online.
            </p>
            <p className="font-medium text-navy">
              Our goal is simple: make your brand easier to notice, easier to
              understand and harder to forget.
            </p>
          </div>
        </Reveal>
        <Reveal className="lg:col-span-6" delay={100}>
          <div className="relative">
            <div className="overflow-hidden rounded-3xl shadow-[var(--shadow-border)]">
              <img
                src={`${import.meta.env.BASE_URL}brand/studio-desk.jpg`}
                alt="A digital branding studio desk with a laptop, phone, colour swatches and creative notes"
                width={1200}
                height={900}
                className="aspect-[4/3] w-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="absolute bottom-5 left-5 hidden max-w-64 rounded-2xl bg-navy p-5 text-paper shadow-[var(--shadow-navy)] sm:block">
              <p className="font-display text-2xl leading-snug">
                Strategy, social and a digital identity that holds together.
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function MissionVision() {
  return (
    <section className="px-5 pb-8 md:px-8">
      <div className="mx-auto grid max-w-6xl gap-5 md:grid-cols-2">
        <Reveal>
          <article className="h-full rounded-[2rem] bg-cream p-8 md:p-10">
            <p className="text-xs font-semibold uppercase tracking-widest text-accent">
              Our mission
            </p>
            <h2 className="mt-4 font-display text-3xl text-navy md:text-4xl">
              Our Mission
            </h2>
            <p className="mt-5 leading-relaxed text-muted">
              To help businesses and entrepreneurs build meaningful digital
              brands by making online branding clearer, more strategic and
              accessible.
            </p>
            <p className="mt-4 leading-relaxed text-muted">
              We want to help brands move beyond simply “being online” and start
              building an online presence that actually communicates their
              value.
            </p>
          </article>
        </Reveal>
        <Reveal delay={80}>
          <article className="h-full rounded-[2rem] bg-navy p-8 text-paper md:p-10">
            <p className="text-xs font-semibold uppercase tracking-widest text-lavender">
              Our vision
            </p>
            <h2 className="mt-4 font-display text-3xl md:text-4xl">
              Our Vision
            </h2>
            <p className="mt-5 leading-relaxed text-paper/75">
              To become a trusted digital branding partner for businesses that
              want to be seen, understood and remembered in an increasingly
              digital world.
            </p>
            <p className="mt-4 leading-relaxed text-paper/75">
              We envision a world where every business — regardless of size —
              has the tools and confidence to present itself professionally
              online.
            </p>
          </article>
        </Reveal>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="scroll-mt-24 px-5 py-20 md:px-8 md:py-28">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">
            What we offer
          </p>
          <h2 className="mt-4 max-w-xl font-display text-4xl text-navy md:text-5xl">
            What We Do
          </h2>
          <p className="mt-4 max-w-xl text-lg text-muted">
            We turn ideas into stronger digital identities.
          </p>
        </Reveal>

        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service, i) => {
            const Icon = SERVICE_ICONS[i] ?? Compass;
            return (
              <Reveal key={service.number} delay={i * 50}>
                <article className="group flex h-full flex-col rounded-[1.75rem] bg-paper p-7 shadow-[var(--shadow-border)] transition-[transform,box-shadow] duration-200 ease-[var(--ease-out)] hover:-translate-y-1 hover:shadow-[var(--shadow-border-hover)]">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold tracking-widest text-muted-soft">
                      {service.number}
                    </span>
                    <Icon
                      className="size-5 text-accent transition-transform duration-200 group-hover:translate-x-0.5"
                      strokeWidth={1.7}
                    />
                  </div>
                  <h3 className="mt-6 font-sans text-sm font-bold uppercase tracking-widest text-navy">
                    {service.title}
                  </h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-muted">
                    {service.body}
                  </p>
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal className="mt-10">
          <Button size="lg" variant="navy" onClick={() => scrollToId("contact")}>
            Let's improve your brand
            <ArrowUpRight className="size-4" />
          </Button>
        </Reveal>
      </div>
    </section>
  );
}

function Problem() {
  return (
    <section className="px-5 pb-8 md:px-8">
      <div className="mx-auto max-w-6xl overflow-hidden rounded-[2rem] bg-cream">
        <div className="grid lg:grid-cols-12">
          <div className="relative lg:col-span-5">
            <img
              src={`${import.meta.env.BASE_URL}brand/strategy-hands.jpg`}
              alt="Hands arranging printed brand identity cards and colour chips on a studio table"
              width={1200}
              height={900}
              className="h-full min-h-72 w-full object-cover"
              loading="lazy"
            />
          </div>
          <div className="lg:col-span-7 p-8 md:p-12">
            <Reveal>
              <h2 className="font-display text-3xl leading-tight text-navy md:text-4xl">
                Is Your Brand Being Seen — But Not Remembered?
              </h2>
            </Reveal>
            <div className="mt-8 space-y-6">
              {PROBLEMS.map((item) => (
                <Reveal key={item.quote}>
                  <blockquote>
                    <p className="font-display text-xl italic text-navy">
                      “{item.quote}”
                    </p>
                    <p className="mt-2 text-sm text-muted">{item.answer}</p>
                  </blockquote>
                </Reveal>
              ))}
            </div>
            <p className="mt-10 font-sans text-sm font-semibold uppercase tracking-widest text-navy">
              Your business may be good. Your online presence should show it.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function WhyPheno() {
  return (
    <section id="why" className="scroll-mt-24 px-5 py-20 md:px-8 md:py-28">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">
            Why Pheno Brand
          </p>
          <h2 className="mt-4 font-display text-4xl text-navy md:text-5xl">
            Why Choose Pheno?
          </h2>
        </Reveal>
        <div className="mt-12 grid gap-4 md:grid-cols-2">
          {REASONS.map((item, i) => (
            <Reveal key={item.title} delay={i * 60}>
              <article className="rounded-[1.75rem] border border-line bg-paper p-8">
                <h3 className="font-sans text-sm font-bold uppercase tracking-widest text-navy">
                  {item.title}
                </h3>
                <p className="mt-3 text-muted">{item.body}</p>
              </article>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-12 rounded-[2rem] bg-lavender-soft px-8 py-12 md:px-14">
          <p className="max-w-3xl font-display text-3xl leading-snug text-navy md:text-4xl">
            “We don't just help you look good online. We help you make
            sense online.”
          </p>
        </Reveal>
      </div>
    </section>
  );
}

function Process() {
  return (
    <section className="px-5 pb-8 md:px-8">
      <div className="mx-auto max-w-6xl rounded-[2rem] bg-navy px-6 py-14 text-paper md:px-12 md:py-20">
        <Reveal>
          <p className="text-xs font-semibold uppercase tracking-widest text-lavender">
            Our process
          </p>
          <h2 className="mt-4 font-display text-4xl md:text-5xl">
            Four steps. One clearer brand.
          </h2>
        </Reveal>
        <div className="relative mt-14 grid gap-10 md:grid-cols-4 md:gap-6">
          <div className="pointer-events-none absolute left-[12%] right-[12%] top-5 hidden h-px bg-paper/15 md:block" />
          {STEPS.map((step, i) => (
            <Reveal key={step.number} delay={i * 80}>
              <article className="relative">
                <div className="flex size-10 items-center justify-center rounded-full bg-lavender text-xs font-bold text-navy">
                  {step.number}
                </div>
                <h3 className="mt-6 font-sans text-sm font-bold uppercase tracking-widest">
                  {step.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-paper/70">
                  {step.body}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function WhoWeHelp() {
  return (
    <section className="px-5 py-20 md:px-8 md:py-28">
      <div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-12">
        <div className="lg:col-span-6">
          <Reveal>
            <p className="text-xs font-semibold uppercase tracking-widest text-accent">
              Who we help
            </p>
            <h2 className="mt-4 font-display text-4xl text-navy md:text-5xl">
              Built For Brands With Something To Say.
            </h2>
            <p className="mt-5 max-w-md leading-relaxed text-muted">
              Whether you're starting from zero or trying to improve an
              existing online presence, Pheno Brand helps you take the next
              step.
            </p>
          </Reveal>
          <div className="mt-8 grid grid-cols-2 gap-3">
            {AUDIENCES.map((name, i) => (
              <Reveal key={name} delay={i * 40}>
                <div className="rounded-2xl bg-cream px-4 py-5 text-sm font-semibold text-navy">
                  {name}
                </div>
              </Reveal>
            ))}
          </div>
        </div>
        <Reveal className="lg:col-span-6" delay={80}>
          <div className="overflow-hidden rounded-[2rem] shadow-[var(--shadow-border)]">
            <img
              src={`${import.meta.env.BASE_URL}brand/collaboration.jpg`}
              alt="Two people reviewing a brand board together in a bright studio"
              width={1600}
              height={900}
              className="aspect-[16/11] w-full object-cover"
              loading="lazy"
            />
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Philosophy() {
  return (
    <section className="grain relative overflow-hidden bg-navy text-paper">
      <div className="mx-auto max-w-6xl px-5 py-24 md:px-8 md:py-32">
        <Reveal>
          <p className="text-xs font-semibold uppercase tracking-widest text-lavender">
            Brand philosophy
          </p>
          <h2 className="mt-6 font-display text-5xl leading-[0.95] sm:text-6xl md:text-8xl">
            Be seen.
            <br />
            Be clear.
            <br />
            Be remembered.
          </h2>
          <p className="mt-8 max-w-xl text-lg leading-relaxed text-paper/70">
            Attention gets people to notice your brand. Clarity helps them
            understand it. Consistency helps them remember it.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

function CallToAction() {
  return (
    <section className="px-5 py-16 md:px-8 md:py-24">
      <Reveal>
        <div className="mx-auto max-w-6xl overflow-hidden rounded-[2rem] bg-accent px-8 py-14 text-accent-fg md:px-16 md:py-20">
          <h2 className="max-w-3xl font-display text-4xl leading-tight md:text-5xl">
            Ready To Give Your Brand A Stronger Digital Presence?
          </h2>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-accent-fg/85">
            Let's turn your online presence into something your audience
            can notice, understand and remember.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button size="lg" variant="invert" onClick={() => scrollToId("contact")}>
              Start with Pheno
              <ArrowRight className="size-4" />
            </Button>
            <Button
              size="lg"
              variant="ghost"
              onClick={() => scrollToId("contact")}
            >
              Contact us
            </Button>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

function Contact() {
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = String(data.get("name") ?? "").trim();
    const email = String(data.get("email") ?? "").trim();
    const brand = String(data.get("brand") ?? "").trim();
    const message = String(data.get("message") ?? "").trim();
    const subject = encodeURIComponent(
      `Brand inquiry from ${name || "a new client"}`,
    );
    const body = encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\nBrand: ${brand}\n\n${message}`,
    );
    window.location.href = `mailto:${SITE.email}?subject=${subject}&body=${body}`;
    setSent(true);
  }

  return (
    <section id="contact" className="scroll-mt-24 px-5 pb-20 md:px-8 md:pb-28">
      <div className="mx-auto grid max-w-6xl gap-12 lg:grid-cols-12">
        <Reveal className="lg:col-span-5">
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">
            Contact
          </p>
          <h2 className="mt-4 font-display text-4xl text-navy md:text-5xl">
            Let's Talk About Your Brand.
          </h2>
          <p className="mt-5 leading-relaxed text-muted">
            Have a business idea, an existing brand or simply want to improve
            your online presence? We'd love to hear from you.
          </p>
          <ul className="mt-8 space-y-3">
            {SOCIALS.map((s) => {
              const Icon = SOCIAL_ICONS[s.id];
              return (
                <li key={s.id}>
                  <a
                    href={s.href}
                    target={s.id === "email" ? undefined : "_blank"}
                    rel={s.id === "email" ? undefined : "noreferrer"}
                    className="group flex min-h-12 items-center gap-4 rounded-2xl bg-cream px-4 py-3 transition-colors duration-150 hover:bg-lavender-soft"
                  >
                    <span className="flex size-10 items-center justify-center rounded-full bg-navy text-paper">
                      <Icon className="size-4" />
                    </span>
                    <span>
                      <span className="block text-xs font-semibold uppercase tracking-widest text-muted">
                        {s.label}
                      </span>
                      <span className="text-sm font-medium text-navy">
                        {s.handle}
                      </span>
                    </span>
                  </a>
                </li>
              );
            })}
          </ul>
        </Reveal>

        <Reveal className="lg:col-span-7" delay={80}>
          <form
            onSubmit={onSubmit}
            className="rounded-[2rem] bg-cream p-6 md:p-10"
          >
            <p className="font-display text-2xl text-navy">Send a note</p>
            <p className="mt-2 text-sm text-muted">
              Tell us a little about your brand. This opens your email app so
              the message goes directly to Pheno Brand.
            </p>
            <div className="mt-8 grid gap-5 sm:grid-cols-2">
              <label className="block text-xs font-semibold uppercase tracking-widest text-muted">
                Name
                <input
                  name="name"
                  required
                  autoComplete="name"
                  className="mt-2 h-12 w-full rounded-xl bg-paper px-4 font-sans text-sm font-medium text-navy outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
                />
              </label>
              <label className="block text-xs font-semibold uppercase tracking-widest text-muted">
                Email
                <input
                  name="email"
                  type="email"
                  required
                  autoComplete="email"
                  className="mt-2 h-12 w-full rounded-xl bg-paper px-4 font-sans text-sm font-medium text-navy outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
                />
              </label>
            </div>
            <label className="mt-5 block text-xs font-semibold uppercase tracking-widest text-muted">
              Brand or business
              <input
                name="brand"
                className="mt-2 h-12 w-full rounded-xl bg-paper px-4 font-sans text-sm font-medium text-navy outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
              />
            </label>
            <label className="mt-5 block text-xs font-semibold uppercase tracking-widest text-muted">
              Message
              <textarea
                name="message"
                required
                rows={5}
                className="mt-2 w-full resize-y rounded-xl bg-paper px-4 py-3 font-sans text-sm font-medium text-navy outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
              />
            </label>
            <Button type="submit" size="lg" className="mt-6">
              {sent ? "Opening your email" : "Send message"}
              <ArrowRight className="size-4" />
            </Button>
          </form>
        </Reveal>
      </div>
    </section>
  );
}
