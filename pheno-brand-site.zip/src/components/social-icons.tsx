import type { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement>;

function base(props: IconProps) {
  return {
    width: 20,
    height: 20,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    ...props,
  };
}

export function InstagramIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="0.6" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function FacebookIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <path d="M14 8h3V4h-3c-2.8 0-5 2.2-5 5v3H6v4h3v8h4v-8h3.2L17 12h-4V9c0-.6.4-1 1-1Z" />
    </svg>
  );
}

export function YoutubeIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <path d="M22.5 7.2a3 3 0 0 0-2.1-2.1C18.6 4.6 12 4.6 12 4.6s-6.6 0-8.4.5A3 3 0 0 0 1.5 7.2 31 31 0 0 0 1 12a31 31 0 0 0 .5 4.8 3 3 0 0 0 2.1 2.1c1.8.5 8.4.5 8.4.5s6.6 0 8.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 23 12a31 31 0 0 0-.5-4.8Z" />
      <path d="m10 15.2 5.2-3.2L10 8.8v6.4Z" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function SnapchatIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <path d="M12 4c2.4 0 4.2 1.7 4.2 4.4 0 1.1.1 1.9.6 2.4.3.3.8.4 1.2.3.2 0 .5-.1.7 0 .4.2.4.7 0 1-.7.6-1.3 1-1.3 1.6 0 1.3 2.2 1.9 2.8 2.2.4.2.5.7.2 1-.4.5-1.3.8-2.4.6-.3 0-.6.2-.7.5-.3.8-1.3 2.2-5.3 2.2s-5-1.4-5.3-2.2c-.1-.3-.4-.5-.7-.5-1.1.2-2 0-2.4-.6-.3-.3-.2-.8.2-1 .6-.3 2.8-.9 2.8-2.2 0-.6-.6-1-1.3-1.6-.4-.3-.4-.8 0-1 .2-.1.5 0 .7 0 .4.1.9 0 1.2-.3.5-.5.6-1.3.6-2.4C7.8 5.7 9.6 4 12 4Z" />
    </svg>
  );
}

export function MailIcon(props: IconProps) {
  return (
    <svg {...base(props)}>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="m4 7 8 6 8-6" />
    </svg>
  );
}

export const SOCIAL_ICONS = {
  instagram: InstagramIcon,
  facebook: FacebookIcon,
  snapchat: SnapchatIcon,
  youtube: YoutubeIcon,
  email: MailIcon,
};
