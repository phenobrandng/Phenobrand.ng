import { cn } from "@/lib/utils";

export function Logo({
  className,
  inverted = false,
}: {
  className?: string;
  inverted?: boolean;
}) {
  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <span className="relative size-10 overflow-hidden rounded-full bg-navy">
        <img
          src={`${import.meta.env.BASE_URL}brand/logo.jpg`}
          alt=""
          width={40}
          height={40}
          className="absolute inset-0 size-full scale-150 object-cover outline-none"
        />
      </span>
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "font-sans text-[0.7rem] font-bold tracking-[0.22em]",
            inverted ? "text-paper" : "text-navy",
          )}
        >
          PHENO BRAND
        </span>
        <span
          className={cn(
            "mt-1 text-[0.58rem] tracking-[0.18em]",
            inverted ? "text-lavender" : "text-muted",
          )}
        >
          BUILD · BRAND · GROW
        </span>
      </span>
    </span>
  );
}
