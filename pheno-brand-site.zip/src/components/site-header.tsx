import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/logo";
import { NAV } from "@/lib/site";
import { cn, scrollToId } from "@/lib/utils";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  function go(id: string) {
    setOpen(false);
    requestAnimationFrame(() => scrollToId(id));
  }

  return (
    <header
      className={cn(
        "sticky top-0 z-50 border-b transition-[background-color,box-shadow,border-color] duration-200",
        scrolled
          ? "border-line bg-paper/90 shadow-[0_8px_30px_-20px_color-mix(in_oklab,var(--color-navy)_40%,transparent)] backdrop-blur-md"
          : "border-transparent bg-paper/80 backdrop-blur-md",
      )}
    >
      <div className="mx-auto flex h-[4.25rem] w-full max-w-6xl items-center justify-between gap-4 px-5 md:h-[4.75rem] md:px-8">
        <button
          type="button"
          onClick={() => go("home")}
          className="rounded-full"
          aria-label="Pheno Brand home"
        >
          <Logo />
        </button>

        <nav className="hidden items-center gap-7 lg:flex" aria-label="Primary">
          {NAV.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => go(item.id)}
              className="font-sans text-sm font-medium text-muted transition-colors duration-150 hover:text-navy"
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <span className="hidden lg:inline-flex">
            <Button variant="navy" onClick={() => go("contact")}>
              Let's build your brand
            </Button>
          </span>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-full text-navy lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-6" /> : <Menu className="size-6" />}
          </button>
        </div>
      </div>

      <div
        className={cn(
          "lg:hidden",
          open ? "pointer-events-auto" : "pointer-events-none",
        )}
      >
        <div
          className={cn(
            "fixed inset-0 top-[4.25rem] bg-navy/30 transition-opacity duration-200 md:top-[4.75rem]",
            open ? "opacity-100" : "opacity-0",
          )}
          onClick={() => setOpen(false)}
        />
        <div
          className={cn(
            "absolute inset-x-0 top-full origin-top border-b border-line bg-paper px-5 py-6 shadow-[var(--shadow-border)] transition-[opacity,transform] duration-200 ease-[var(--ease-smooth-out)] md:px-8",
            open ? "scale-100 opacity-100" : "scale-[0.98] opacity-0",
          )}
        >
          <nav className="flex flex-col gap-1" aria-label="Mobile">
            {NAV.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => go(item.id)}
                className="flex min-h-12 items-center justify-between rounded-xl px-3 text-left font-display text-2xl text-navy hover:bg-cream"
              >
                {item.label}
              </button>
            ))}
          </nav>
          <Button
            variant="navy"
            className="mt-5 w-full"
            onClick={() => go("contact")}
          >
            Let's build your brand
          </Button>
        </div>
      </div>
    </header>
  );
}
