import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-sans font-semibold uppercase tracking-widest transition-[background-color,color,box-shadow,transform] duration-150 ease-[var(--ease-out)] active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        primary:
          "bg-accent text-accent-fg shadow-[0_10px_24px_-12px_color-mix(in_oklab,var(--color-accent)_70%,transparent)] hover:bg-accent-hover",
        navy: "bg-navy text-paper hover:bg-navy-soft",
        outline:
          "bg-transparent text-navy shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] hover:bg-cream",
        invert: "bg-paper text-navy hover:bg-cream",
        ghost:
          "bg-transparent text-paper shadow-[inset_0_0_0_1px_color-mix(in_oklab,var(--color-paper)_28%,transparent)] hover:bg-paper-ghost",
      },
      size: {
        md: "h-12 rounded-full px-6 text-xs",
        lg: "h-14 rounded-full px-8 text-xs",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
    },
  },
);

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

export function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: ButtonProps) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  );
}

export { buttonVariants };
