import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { HomePage } from "@/components/home-page";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import "./styles.css";

function App() {
  return (
    <div className="min-h-screen bg-paper">
      <SiteHeader />
      <HomePage />
      <SiteFooter />
    </div>
  );
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
