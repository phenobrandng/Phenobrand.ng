export const SITE = {
  name: "Pheno Brand",
  handle: "@pheno_brandng",
  handleBare: "pheno_brandng",
  title: "Pheno Brand | Digital Branding & Online Presence Solutions",
  description:
    "Pheno Brand helps businesses build stronger digital brands through digital branding, social media strategy, content strategy and online presence solutions.",
  keywords:
    "digital branding, digital marketing, social media branding, brand strategy, online presence, content strategy, small business branding, business branding, digital brand agency",
  email: "officialmindfulsoul@gmail.com",
  tagline: "Your Brand Deserves To Be Seen, Understood & Remembered.",
  positioning:
    "We help your brand look better, communicate better and reach the right people online.",
};

export const NAV = [
  { label: "Home", id: "home" },
  { label: "About", id: "about" },
  { label: "Services", id: "services" },
  { label: "Why Pheno", id: "why" },
  { label: "Contact", id: "contact" },
] as const;

export const SOCIALS = [
  {
    label: "Instagram",
    handle: "@pheno_brandng",
    href: "https://instagram.com/pheno_brandng",
    id: "instagram" as const,
  },
  {
    label: "Facebook",
    handle: "pheno_brandng",
    href: "https://facebook.com/pheno_brandng",
    id: "facebook" as const,
  },
  {
    label: "Snapchat",
    handle: "phenobrandng",
    href: "https://www.snapchat.com/add/phenobrandng",
    id: "snapchat" as const,
  },
  {
    label: "YouTube",
    handle: "phenobrandng",
    href: "https://youtube.com/@phenobrandng",
    id: "youtube" as const,
  },
  {
    label: "Email",
    handle: "officialmindfulsoul@gmail.com",
    href: "mailto:officialmindfulsoul@gmail.com",
    id: "email" as const,
  },
];

export const SERVICES = [
  {
    number: "01",
    title: "Digital Brand Strategy",
    body: "We help you clarify your brand message, audience and online direction so your digital presence has a clear purpose.",
  },
  {
    number: "02",
    title: "Social Media Branding",
    body: "We help businesses create a consistent and professional presence across their social platforms — from profile optimization and bio improvement to content direction, brand consistency and social media strategy.",
  },
  {
    number: "03",
    title: "Content Strategy",
    body: "We help you understand what to post, who you are posting for and how your content can communicate your brand effectively.",
  },
  {
    number: "04",
    title: "Online Presence Setup",
    body: "We help businesses organize and improve the important parts of their digital presence, from social profiles to basic online platforms.",
  },
  {
    number: "05",
    title: "Brand Content & Creative Direction",
    body: "We help transform business ideas into engaging content concepts that attract attention and communicate value.",
  },
  {
    number: "06",
    title: "Digital Brand Audit",
    body: "We review your current online presence and identify areas that could be improved for clarity, consistency and professionalism.",
  },
];

export const PROBLEMS = [
  {
    quote: "I don't know what to post.",
    answer: "We help you develop clearer content direction.",
  },
  {
    quote: "People visit my page but don't understand what I offer.",
    answer: "We help simplify your message.",
  },
  {
    quote: "My social media doesn't look professional.",
    answer: "We help improve your brand presentation and consistency.",
  },
  {
    quote: "I have a business, but my online presence doesn't reflect it.",
    answer: "We help turn your online presence into a better representation of your business.",
  },
];

export const REASONS = [
  {
    title: "Clarity",
    body: "We make complicated brand messages easier to understand.",
  },
  {
    title: "Creativity",
    body: "We combine strategy with creative ideas that help brands stand out.",
  },
  {
    title: "Audience-first thinking",
    body: "We focus on reaching the right people, not simply collecting followers.",
  },
  {
    title: "Practical strategy",
    body: "We focus on ideas and solutions that businesses can actually use.",
  },
];

export const STEPS = [
  {
    number: "01",
    title: "Discover",
    body: "We learn about your business, audience and goals.",
  },
  {
    number: "02",
    title: "Define",
    body: "We clarify your message, positioning and digital direction.",
  },
  {
    number: "03",
    title: "Build",
    body: "We develop the branding, content direction and online presence.",
  },
  {
    number: "04",
    title: "Grow",
    body: "We help you improve, connect with your audience and build consistently.",
  },
];

export const AUDIENCES = [
  "Small Businesses",
  "Entrepreneurs",
  "Startups",
  "Personal Brands",
  "Online Businesses",
  "Growing Businesses",
];
